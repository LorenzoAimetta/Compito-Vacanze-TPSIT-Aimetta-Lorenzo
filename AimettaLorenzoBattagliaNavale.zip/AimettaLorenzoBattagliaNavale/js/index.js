//navi scelte
/*
1 : (4 x 1)
2 : (3 x 1)
3 :(2 x 1)
2 : (1 x 1)

*/


//variabili globali
let mCaselle = [];//matrice con celle griglia
const lato = 8;
const TEMPO = 45;

let tentativiEffettuati = 0;
let tentativiRimanenti = 45;
let celleTrovate = 0;//su 18
let timer;
let sec = TEMPO;


//lunghezza di ogni nave da posizionare
const navi = [4, 3, 3, 2, 2, 2, 1, 1];

//colore associato ad ogni nave
const coloriNavi = [
    "red",        // (4)
    "orange",     // (3)
    "yellow",     // (3)
    "green",      // (2)
    "purple",     // (2)
    "brown",      // (2)
    "pink",       // (1)
    "gray"        // (1)
];

//colore acqua 
const coloreAcqua = "#1e6fd9";

let griglia;

window.onload = function () {

    griglia = document.getElementById("griglia");
    for (let i = 0; i < lato * lato; i++) {
        const r = Math.floor(i / lato);//riga della cella
        const c = i % lato;//colonna della cella

        let cella = document.createElement("div");
        cella.classList.add("cella");
        griglia.append(cella);
        cella.addEventListener("click", function () {
            gioca(r, c);
        });
    }

    //popolo matrice: ogni casella parte senza nave e "collegata" al suo div
    for (let riga = 0; riga < lato; riga++) {
        mCaselle[riga] = [];
        for (let col = 0; col < lato; col++) {
            const indice = riga * lato + col;
            mCaselle[riga][col] = {
                nave: false,
                colore: coloreAcqua,
                cella: griglia.children[indice],//mi da una lista di tutti gli elementi conenuti i griglia
                cliccata: false,
            };
        }
    }

    posizionaNavi();

    timer = setInterval(() => {
        crono();
    }, 1000);

    document.getElementById("tentativiEffettuati").innerHTML = tentativiEffettuati;
    document.getElementById("tentativiRimanenti").innerHTML = tentativiRimanenti;

}
function crono() {
    if (sec == 0) {

        clearInterval(timer);
        document.getElementById("griglia").classList.add("disabilita");
        document.getElementById("messFinale").innerHTML = `<br>
    <span class="text-danger fw-bold fs-4 animate__animated animate__shakeX">
        ❌ Peccato, hai perso!! 🏴‍☠️
    </span>
    `;
        document.getElementById("btnSvela").classList.remove("disabled");
    } else {
        sec--;
    }

    if (sec == 25) {
        document.getElementById("t1").classList.remove("bg-success")
        document.getElementById("t2").classList.remove("bg-success")

        document.getElementById("t1").classList.add("bg-warning")
        document.getElementById("t2").classList.add("bg-warning")
    }
    else if (sec == 10) {
        document.getElementById("t1").classList.remove("bg-warning")
        document.getElementById("t2").classList.remove("bg-warning")

        document.getElementById("t1").classList.add("bg-danger")
        document.getElementById("t2").classList.add("bg-danger")
    }

    document.getElementById("secondiRimanenti").innerHTML = sec;
}

//piazzo navi senza sovrapp
function posizionaNavi() {

    for (let n = 0; n < navi.length; n++) {
        const lunghezza = navi[n];
        let posizionata = false;


        while (!posizionata) {
            let orizzontale;
            (Math.random() < 0.5) ? orizzontale = true : orizzontale = false;
            const riga = Math.floor(Math.random() * lato);
            const col = Math.floor(Math.random() * lato);

            if (posizionePossibile(riga, col, lunghezza, orizzontale)) {
                for (let k = 0; k < lunghezza; k++) {
                    const r = orizzontale ? riga : riga + k;
                    const c = orizzontale ? col + k : col;
                    mCaselle[r][c].nave = true;
                    mCaselle[r][c].colore = coloriNavi[n];
                }
                posizionata = true;
            }
        }
    }
}

//controllo che la nave stia dentro la griglia e non tocchi altre navi
function posizionePossibile(riga, col, lunghezza, orizzontale) {

    for (let k = 0; k < lunghezza; k++) {
        const r = orizzontale ? riga : riga + k;
        const c = orizzontale ? col + k : col;

        //fuori da griglia
        if (r < 0 || r >= lato || c < 0 || c >= lato) {
            return false;
        }

        //casella occupata
        if (mCaselle[r][c].nave) {
            return false;
        }
    }
    return true;
}

function gioca(r, c) {
    //coloro
    if (mCaselle[r][c].nave) {
        mCaselle[r][c].cella.classList.add("nave");
    } else {
        mCaselle[r][c].cella.classList.add("acqua");

    }

    mCaselle[r][c].cella.style.backgroundColor = mCaselle[r][c].colore;

    
    if (mCaselle[r][c].cliccata == false) {
        mCaselle[r][c].cliccata = true;

        tentativiEffettuati++;
        tentativiRimanenti--;

        if (mCaselle[r][c].colore != "#1e6fd9") {
            celleTrovate++;
        }

    }

    document.getElementById("tentativiEffettuati").innerHTML = tentativiEffettuati;
    document.getElementById("tentativiRimanenti").innerHTML = tentativiRimanenti;
    document.getElementById("colpita").innerHTML = celleTrovate;

    controlloWin();

}
function controlloWin() {
    if (celleTrovate == 18) {
        clearInterval(timer);
        document.getElementById("griglia").classList.add("disabilita");
        document.getElementById("messFinale").innerHTML = `<br>
            <span class="text-success fw-bold fs-5">
                Grandioso! Hai vinto!! 🏆⚓
            </span>
        `;
        return;
    }
    if (tentativiRimanenti == 0) {
        clearInterval(timer);
        document.getElementById("griglia").classList.add("disabilita");
        document.getElementById("messFinale").innerHTML = `<br>
    <span class="text-danger fw-bold fs-4 animate__animated animate__shakeX">
        ❌ Peccato, hai perso!! 🏴‍☠️
    </span>
    `;

        document.getElementById("btnSvela").classList.remove("disabled");
    }
}


function reset() {
    // Ripristino matrice e grafica delle celle
    for (let riga = 0; riga < lato; riga++) {
        for (let col = 0; col < lato; col++) {
            mCaselle[riga][col].nave = false;
            mCaselle[riga][col].colore = coloreAcqua;
            mCaselle[riga][col].cliccata = false;

            // Rimuovo stili
            mCaselle[riga][col].cella.classList.remove("nave");
            mCaselle[riga][col].cella.classList.remove("acqua");
            mCaselle[riga][col].cella.style.backgroundColor = "";
        }
    }

    document.getElementById("griglia").classList.remove("disabilita");
    document.getElementById("messFinale").innerHTML = "";
    document.getElementById("btnSvela").classList.add("disabled");


    tentativiEffettuati = 0;
    tentativiRimanenti = 45;
    celleTrovate = 0;

    document.getElementById("tentativiEffettuati").innerHTML = tentativiEffettuati;
    document.getElementById("tentativiRimanenti").innerHTML = tentativiRimanenti;
    document.getElementById("colpita").innerHTML = celleTrovate;


    posizionaNavi();


    // Reset del timer
    sec = TEMPO;
    clearInterval(timer);

    document.getElementById("secondiRimanenti").innerHTML = sec;

    timer = setInterval(() => {
        crono();
    }, 1000);

    document.getElementById("t1").classList.remove("bg-danger");
    document.getElementById("t2").classList.remove("bg-danger");
    document.getElementById("t1").classList.remove("bg-warning");
    document.getElementById("t2").classList.remove("bg-warning");
    document.getElementById("t1").classList.remove("bg-success");
    document.getElementById("t2").classList.remove("bg-success");

    document.getElementById("t1").classList.add("bg-success");
    document.getElementById("t2").classList.add("bg-success");

}
//svelo solo se perdo
function svela() {
    for (let r = 0; r < lato; r++)
        for (let c = 0; c < lato; c++)
            mCaselle[r][c].cella.style.backgroundColor = mCaselle[r][c].colore;

}